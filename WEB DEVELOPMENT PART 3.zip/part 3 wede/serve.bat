@echo off
set PORT=8000
python -m http.server %PORT% 2>nul || py -m http.server %PORT%
if %ERRORLEVEL% NEQ 0 (
  echo Python not found. Install Python or use 'npx serve' or VS Code Live Server.
)
pause
