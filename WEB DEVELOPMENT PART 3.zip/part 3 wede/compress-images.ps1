# compress-images.ps1
# Uses ImageMagick (`magick`) to create compressed copies of the resource images.
# Run from project root: .\compress-images.ps1

$map = @(
  @{in='images/business plan.webp'; out='images/business-plan-compressed.webp'},
  @{in='images/money tracker.jpg'; out='images/money-tracker-compressed.jpg'},
  @{in='images/presentation.jpg'; out='images/presentation-compressed.jpg'},
  @{in='images/marketing.webp'; out='images/marketing-compressed.webp'}
)

function Check-Command($cmd){
  try { Get-Command $cmd -ErrorAction Stop > $null; return $true } catch { return $false }
}

if (-not (Check-Command 'magick')){
  Write-Error "ImageMagick 'magick' not found. Install ImageMagick and ensure 'magick' is on PATH."
  exit 1
}

foreach ($item in $map){
  $in = $item.in
  $out = $item.out
  if (-not (Test-Path $in)){
    Write-Warning "Input not found: $in — skipping"
    continue
  }

  Write-Host "Compressing $in -> $out"

  # Generic compression: resize only if larger than 1600px, reduce quality, strip metadata
  try{
    & magick "$in" -strip -quality 75 -resize 1600x1600^> "$out"
    Write-Host "Created $out"
  } catch {
    Write-Error "Failed to compress $in : $_"
  }
}

Write-Host "Done. If images look good, open the site or run the local server (see serve.ps1 / serve.bat)."