Param(
  [int]$Port = 8000
)

if (Get-Command python -ErrorAction SilentlyContinue) {
  Write-Host "Starting Python http.server on port $Port..."
  python -m http.server $Port
} elseif (Get-Command py -ErrorAction SilentlyContinue) {
  Write-Host "Starting Python (py) http.server on port $Port..."
  py -m http.server $Port
} else {
  Write-Error "Python not found. Install Python, or use 'npx serve' or the VS Code Live Server extension."
}
