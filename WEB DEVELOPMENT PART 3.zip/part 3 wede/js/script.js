// Global script for ThriveHub UI interactions
(function(){
  'use strict';

  // helper
  const $ = (sel, ctx=document) => ctx.querySelector(sel);
  const $$ = (sel, ctx=document) => Array.from(ctx.querySelectorAll(sel));

  // Navbar scroll shadow
  const navbar = $('.navbar');
  function onScroll(){
    if(!navbar) return;
    if(window.scrollY > 10) navbar.classList.add('scrolled');
    else navbar.classList.remove('scrolled');
  }
  window.addEventListener('scroll', onScroll, {passive:true});
  onScroll();

  // Mobile menu
  const burger = $('.hamburger');
  const navLinks = $('.nav-links');
  if(burger && navLinks){
    burger.addEventListener('click', ()=>{
      navLinks.classList.toggle('open');
      burger.setAttribute('aria-expanded', String(navLinks.classList.contains('open')));
    });
  }

  // Dark mode toggle
  const dmToggle = $('#dark-toggle');
  function applyTheme(theme){
    if(theme==='dark') document.documentElement.classList.add('dark');
    else document.documentElement.classList.remove('dark');
  }
  const saved = localStorage.getItem('thrive:theme');
  if(saved) applyTheme(saved);
  if(dmToggle){
    dmToggle.addEventListener('click', ()=>{
      const isDark = document.documentElement.classList.toggle('dark');
      localStorage.setItem('thrive:theme', isDark ? 'dark' : 'light');
    });
  }

  // Animated counters (data-target attribute)
  const counters = $$('[data-counter]');
  if(counters.length){
    const obs = new IntersectionObserver(entries=>{
      entries.forEach(entry=>{
        if(entry.isIntersecting){
          const el = entry.target;
          const target = parseInt(el.getAttribute('data-target')||'0',10);
          let start = 0;
          const dur = 1200;
          const step = Math.max(1, Math.floor(target / (dur/16)));
          const timer = setInterval(()=>{
            start += step;
            if(start >= target){ el.textContent = String(target)+'+'; clearInterval(timer); }
            else el.textContent = String(start)+'+';
          },16);
          obs.unobserve(el);
        }
      });
    },{threshold:0.5});
    counters.forEach(c=>obs.observe(c));
  }

  // Contact form intercept
  const contactForms = $$('form[data-contact]');
  contactForms.forEach(form=>{
    form.addEventListener('submit', e=>{
      e.preventDefault();
      const container = document.createElement('div');
      container.className = 'contact-thanks';
      container.innerHTML = '<h3>Thank you!</h3><p>We received your message and will be in touch shortly.</p>';
      form.replaceWith(container);
    });
  });

  // Download modal flow
  function createModal(){
    if($('#download-modal')) return;
    const modal = document.createElement('div');
    modal.id = 'download-modal'; modal.className='modal hidden';
    modal.innerHTML = `
      <div class="modal-card">
        <button class="modal-close" style="float:right;border:none;background:transparent;font-size:18px;cursor:pointer">✕</button>
        <h3>Get the resource</h3>
        <p>Please enter your email to receive the download link.</p>
        <form id="download-form">
          <input type="email" name="email" placeholder="Email address" required style="width:100%;padding:10px;margin:10px 0;border:1px solid #ccc;border-radius:6px">
          <input type="hidden" name="file" value="">
          <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:8px;">
            <button type="button" class="btn btn-cancel">Cancel</button>
            <button type="submit" class="btn">Get Download</button>
          </div>
        </form>
      </div>
    `;
    document.body.appendChild(modal);

    const closeBtn = modal.querySelector('.modal-close');
    const cancel = modal.querySelector('.btn-cancel');
    function hide(){ modal.classList.add('hidden'); }
    closeBtn.addEventListener('click', hide);
    cancel.addEventListener('click', hide);

    const downloadForm = $('#download-form');
    downloadForm.addEventListener('submit', e=>{
      e.preventDefault();
      const email = downloadForm.email.value;
      const file = downloadForm.file.value || '#';
      // In a production site, send email to server and generate link.
      hide();
      // Trigger a fake download using anchor (if file exists it will download)
      const a = document.createElement('a');
      a.href = file;
      a.download = '';
      document.body.appendChild(a);
      a.click();
      a.remove();
      // show quick toast
      const t = document.createElement('div'); t.style.position='fixed';t.style.right='20px';t.style.bottom='20px';t.style.background='#222';t.style.color='#fff';t.style.padding='10px 14px';t.style.borderRadius='8px';t.textContent='Thanks — check your download.';document.body.appendChild(t);
      setTimeout(()=>t.remove(),3200);
    });
  }
  createModal();

  // Attach download buttons
  $$('[data-download]').forEach(btn=>{
    btn.addEventListener('click', e=>{
      e.preventDefault();
      const file = btn.getAttribute('data-download') || btn.getAttribute('href') || '#';
      const modal = $('#download-modal');
      modal.classList.remove('hidden');
      modal.querySelector('input[name=file]').value = file;
    });
  });

  // Search & filter (resources & blog)
  function setupSearch(containerSelector, itemSelector){
    const container = document.querySelector(containerSelector);
    if(!container) return;
    const input = container.querySelector('.search-bar input');
    const filters = container.querySelectorAll('.filters button');
    const items = container.querySelectorAll(itemSelector);

    function apply(){
      const q = (input && input.value || '').toLowerCase().trim();
      const active = Array.from(filters).find(b=>b.classList.contains('active'));
      const cat = active ? active.getAttribute('data-cat') : null;
      items.forEach(it=>{
        const title = (it.getAttribute('data-title')||it.textContent||'').toLowerCase();
        const itemCat = it.getAttribute('data-category') || '';
        const matchesQ = q === '' || title.indexOf(q) !== -1;
        const matchesCat = !cat || cat === 'all' || itemCat === cat;
        it.style.display = (matchesQ && matchesCat) ? '' : 'none';
      });
    }
    if(input) input.addEventListener('input', apply);
    filters.forEach(b=>b.addEventListener('click', ()=>{filters.forEach(x=>x.classList.remove('active'));b.classList.add('active');apply();}));
  }
  setupSearch('#resources-section', '.resource-card');
  setupSearch('#blog-section', '.post-card');

  /* -------------------- Lightbox Gallery -------------------- */
  function setupLightbox(){
    const items = $$('img.lightbox-item');
    if(!items.length) return;
    let lb = document.createElement('div'); lb.className='modal hidden'; lb.id='lightbox-modal';
    lb.innerHTML = '<div class="modal-card"><button class="modal-close">✕</button><div class="lb-content" style="text-align:center"></div></div>';
    document.body.appendChild(lb);
    const content = lb.querySelector('.lb-content');
    lb.querySelector('.modal-close').addEventListener('click', ()=>lb.classList.add('hidden'));
    items.forEach(img=>{
      img.style.cursor='zoom-in';
      img.addEventListener('click', ()=>{
        content.innerHTML = '';
        const big = document.createElement('img'); big.src = img.src; big.alt = img.alt || '';
        big.style.maxWidth='100%'; big.style.height='auto'; big.style.borderRadius='6px';
        content.appendChild(big);
        lb.classList.remove('hidden');
      });
    });
  }
  setupLightbox();

  /* -------------------- Dynamic Blog Loading -------------------- */
  function loadBlogPosts(){
    const grid = document.querySelector('#blog-section .grid');
    if(!grid) return;
    // example dynamic data (would normally come from a server)
    const posts = [
      {title:'Start a Business', category:'startup', img:'https://images.unsplash.com/photo-1556761175-5973dc0f32e7?w=600', excerpt:'Learn simple steps to start your first business.'},
      {title:'Marketing', category:'marketing', img:'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=600', excerpt:'Easy ways to promote your business online.'},
      {title:'Funding', category:'funding', img:'https://images.unsplash.com/photo-1521791136064-7986c2920216?w=600', excerpt:'Find ways to get money to grow your business.'}
    ];
    grid.innerHTML = '';
    posts.forEach(p=>{
      const card = document.createElement('div'); card.className='card post-card'; card.setAttribute('data-title', p.title); card.setAttribute('data-category', p.category);
      card.innerHTML = `<img src="${p.img}" alt="${p.title}"><div class="card-body"><h3 style="color:var(--green)">${p.title}</h3><p>${p.excerpt}</p><a href="#" class="read-more">Read More</a></div>`;
      grid.appendChild(card);
    });
  }
  loadBlogPosts();

  /* -------------------- Accordions on Services -------------------- */
  function setupAccordions(){
    const acc = $$('.accordion');
    if(!acc.length) return;
    acc.forEach(a=>{
      const head = a.querySelector('.acc-head');
      const body = a.querySelector('.acc-body');
      body.style.maxHeight = '0px'; body.style.overflow='hidden'; body.style.transition='max-height .35s ease';
      head.addEventListener('click', ()=>{
        const open = head.classList.toggle('open');
        if(open) body.style.maxHeight = body.scrollHeight + 'px';
        else body.style.maxHeight = '0px';
      });
    });
  }
  setupAccordions();

  /* -------------------- Tabs for Resources -------------------- */
  function setupTabs(){
    const tabWrappers = $$('.tabs');
    tabWrappers.forEach(wrapper=>{
      const tabs = wrapper.querySelectorAll('[data-tab]');
      const panes = wrapper.querySelectorAll('.tab-pane');
      tabs.forEach(t=>t.addEventListener('click', ()=>{
        tabs.forEach(x=>x.classList.remove('active')); t.classList.add('active');
        const id = t.getAttribute('data-tab');
        panes.forEach(p=>p.classList.toggle('hidden', p.id !== id));
      }));
    });
  }
  setupTabs();

  /* -------------------- Leaflet map (contact) -------------------- */
  function setupLeaflet(){
    if(typeof L === 'undefined') return; // leaflet not loaded
    const mapEl = document.getElementById('leaflet-map');
    if(!mapEl) return;
    const map = L.map(mapEl).setView([-26.2041,27.9473], 11);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {maxZoom:19, attribution:'© OpenStreetMap'}).addTo(map);
    L.marker([-26.2041,27.9473]).addTo(map).bindPopup('ThriveHub - Johannesburg').openPopup();
  }
  // attempt to initialize after DOM loaded
  window.addEventListener('load', setupLeaflet);

  /* -------------------- Client-side validation + AJAX form submit -------------------- */
  function enhanceForms(){
    const contact = document.querySelector('form.contact-form');
    if(!contact) return;
    contact.addEventListener('submit', function(e){
      e.preventDefault();
      // basic validation
      const name = contact.querySelector('[name=name]');
      const email = contact.querySelector('[name=email]');
      if(!name.value.trim() || !email.value.trim()){ alert('Please fill name and email.'); return; }
      if(!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email.value)) { alert('Please enter a valid email.'); return; }
      // simulate AJAX
      const data = {name: name.value, email: email.value, subject: contact.subject.value, message: contact.message.value};
      setTimeout(()=>{
        contact.replaceWith((()=>{ const d=document.createElement('div'); d.className='contact-thanks'; d.innerHTML='<h3>Thanks '+(name.value||'')+'</h3><p>Your message was sent.</p>'; return d; })());
      }, 700);
    });
  }
  enhanceForms();

})();
